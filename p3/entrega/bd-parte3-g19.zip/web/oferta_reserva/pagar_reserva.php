<html>
<head>
    <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <META HTTP-EQUIV="Expires" CONTENT="-1">
    <title>BD 2016/2017 - InstantOffice</title>
    <meta charset="UTF-8" http-equiv="content-language" content="pt">
    <link rel="stylesheet" href="../styles.css">
</head>
    <body>
        <h3>Pagar Reserva</h3>
        <form action="atualizar_reserva.php" method="post">
            <p>Numero de Reserva: <input type="text" name="number"/></p>
            <p>Método: <input type="text" name="method"/></p>
            <p><input type="submit" value="Submit"/></p>
        </form>
        <div style="text-align:center;"><a href="gerir_oferta_reserva.php">Voltar</a></div>
    </body>
</html>